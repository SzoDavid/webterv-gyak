<?php

session_start();
// Ki kell  törölni a session adatokat
header('Location: ../login.php');

